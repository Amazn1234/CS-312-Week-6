import React from "react";

//pass in props from app.js
function Note(props) {
  return (
    //insert props values as js vars
    <div className="note">
      <h1>{props.title}</h1>
      <p>{props.content}</p>
    </div>
  );
}

export default Note;
