import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";

//import notes function
import notes from "../notes";

//create a function to make new notes
function createNotes(noteItem) {
  return (
    //create components from items in notes.js
    //set unique key for every item along with name and content
    <Note
      key={noteItem.key}
      title={noteItem.title}
      content={noteItem.content}
    />
  );
}

//use createNotes funtion to insert a list of all created components
function App() {
  return (
    <div>
      <Header />
      {notes.map(createNotes)};
      <Footer />
    </div>
  );
}

export default App;
